package seleniumFirstClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumFirstScript {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://accounts.bukalapak.com/login");
		driver.manage().window().maximize();
		driver.findElement(By.id("user_session_username")).sendKeys("amir.281198@gmail.com");
		driver.findElement(By.id("user_session_password")).sendKeys("EMAchan12");
		//driver.findElement(By.className("c-btn c-btn--red c-btn--block js-btn-menu-login")).click();
		driver.findElement(By.name("commit")).click();
		
		String at = driver.getTitle();
		String et = "login";
		driver.close();
		if(at.equalsIgnoreCase(et)) {
			System.out.println("Test Successful");
		}
		else {
			System.out.println("Test Failure");
		}
		
	}

}
